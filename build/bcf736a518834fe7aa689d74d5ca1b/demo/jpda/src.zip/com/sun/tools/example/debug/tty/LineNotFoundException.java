/*
 * Copyright 1998-2001 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.tty;

public class LineNotFoundException extends Exception
{
    public LineNotFoundException()
    {
        super();
    }

    public LineNotFoundException(String s)
    {
        super(s);
    }
}
